import { Preferences } from '@capacitor/preferences';
import { Capacitor } from '@capacitor/core';

const KEY = 'myagenda.events.v1';

export async function loadEvents() {
  try {
    if (Capacitor.isNativePlatform()) {
      const result = await Preferences.get({ key: KEY });
      return result.value ? JSON.parse(result.value) : [];
    }
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (error) {
    console.error('No se pudieron cargar los eventos:', error);
    return [];
  }
}

export async function saveEvents(events) {
  const value = JSON.stringify(events);
  if (Capacitor.isNativePlatform()) {
    await Preferences.set({ key: KEY, value });
  } else {
    localStorage.setItem(KEY, value);
  }
}
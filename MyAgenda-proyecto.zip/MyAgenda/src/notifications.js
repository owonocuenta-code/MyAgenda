import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';

export async function requestNotificationPermission() {
  if (!Capacitor.isNativePlatform()) return { display: 'granted' };
  let permission = await LocalNotifications.checkPermissions();
  if (permission.display !== 'granted') {
    permission = await LocalNotifications.requestPermissions();
  }
  return permission;
}

export async function scheduleReminder(event) {
  if (!Capacitor.isNativePlatform() || !event.reminder || !event.date || !event.time) return;
  const at = new Date(`${event.date}T${event.time}:00`);
  if (Number.isNaN(at.getTime()) || at <= new Date()) return;

  const permission = await requestNotificationPermission();
  if (permission.display !== 'granted') return;

  const id = Math.abs(hashCode(event.id)) % 2147483000 + 1;
  await LocalNotifications.cancel({ notifications: [{ id }] }).catch(() => {});
  await LocalNotifications.schedule({
    notifications: [{
      id,
      title: event.title || 'Recordatorio de MyAgenda',
      body: event.notes || 'Tienes una actividad programada.',
      schedule: { at, allowWhileIdle: true },
      extra: { eventId: event.id }
    }]
  });
}

export async function cancelReminder(event) {
  if (!Capacitor.isNativePlatform()) return;
  const id = Math.abs(hashCode(event.id)) % 2147483000 + 1;
  await LocalNotifications.cancel({ notifications: [{ id }] }).catch(() => {});
}

function hashCode(value) {
  let hash = 0;
  for (let i = 0; i < value.length; i++) hash = ((hash << 5) - hash) + value.charCodeAt(i) | 0;
  return hash;
}
import { useEffect, useMemo, useState } from 'react';
import {
  CalendarDays, CheckCircle2, Circle, Clock3, Plus, Search, StickyNote,
  Settings, ChevronLeft, ChevronRight, LayoutDashboard, ListTodo, X,
  Bell, Trash2, Pencil, CalendarCheck, Flag
} from 'lucide-react';
import { loadEvents, saveEvents } from './storage';
import { scheduleReminder, cancelReminder, requestNotificationPermission } from './notifications';

const today = new Date();
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const dateLabel = (value, options = { weekday: 'long', day: 'numeric', month: 'long' }) =>
  new Date(`${value}T12:00:00`).toLocaleDateString('es-ES', options);
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;

const initialForm = (date) => ({
  id: '', title: '', date, time: '09:00', category: 'Personal',
  priority: 'Normal', notes: '', reminder: false, done: false
});

export default function App() {
  const [events, setEvents] = useState([]);
  const [tab, setTab] = useState('home');
  const [view, setView] = useState('month');
  const [selectedDate, setSelectedDate] = useState(iso(today));
  const [month, setMonth] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(initialForm(iso(today)));
  const [query, setQuery] = useState('');
  const [loaded, setLoaded] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    loadEvents().then(data => { setEvents(data); setLoaded(true); });
  }, []);

  useEffect(() => {
    if (loaded) saveEvents(events).catch(console.error);
  }, [events, loaded]);

  const sorted = useMemo(() => [...events].sort((a,b) =>
    `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`)), [events]);
  const dayEvents = sorted.filter(e => e.date === selectedDate);
  const pending = events.filter(e => !e.done);
  const completed = events.filter(e => e.done);
  const upcoming = sorted.filter(e => !e.done && e.date >= iso(today)).slice(0,4);

  function changeMonth(delta) {
    setMonth(new Date(month.getFullYear(), month.getMonth() + delta, 1));
  }
  function openNew(date = selectedDate) {
    setForm(initialForm(date)); setModal(true);
  }
  function openEdit(event) { setForm({ ...event }); setModal(true); }
  async function submit(e) {
    e.preventDefault();
    if (!form.title.trim()) return;
    const item = { ...form, id: form.id || uid(), title: form.title.trim() };
    setEvents(old => form.id ? old.map(x => x.id === form.id ? item : x) : [...old, item]);
    if (form.id) await cancelReminder(form);
    if (item.reminder) await scheduleReminder(item);
    setSelectedDate(item.date);
    setModal(false);
    setNotice('Actividad guardada');
    setTimeout(() => setNotice(''), 2200);
  }
  async function toggleDone(event) {
    const updated = { ...event, done: !event.done };
    setEvents(old => old.map(x => x.id === event.id ? updated : x));
    if (updated.done) await cancelReminder(event);
    else if (updated.reminder) await scheduleReminder(updated);
  }
  async function removeEvent(event) {
    await cancelReminder(event);
    setEvents(old => old.filter(x => x.id !== event.id));
  }
  function shiftDate(delta) {
    const d = new Date(`${selectedDate}T12:00:00`);
    d.setDate(d.getDate() + delta);
    const next = iso(d); setSelectedDate(next);
    setMonth(new Date(d.getFullYear(), d.getMonth(), 1));
  }

  const monthTitle = month.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' });
  const calendarDays = (() => {
    const first = new Date(month.getFullYear(), month.getMonth(), 1);
    const offset = (first.getDay() + 6) % 7;
    const count = new Date(month.getFullYear(), month.getMonth()+1, 0).getDate();
    return [...Array(Math.ceil((offset+count)/7)*7)].map((_,i) => {
      const day = i-offset+1;
      return day < 1 || day > count ? null : iso(new Date(month.getFullYear(), month.getMonth(), day));
    });
  })();

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand-mark"><CalendarCheck size={21}/></div>
        <div className="brand-copy"><strong>MyAgenda</strong><span>Organiza tu día</span></div>
        <button className="icon-btn" aria-label="Ajustes" onClick={() => setTab('settings')}><Settings size={20}/></button>
      </header>

      <main className="content">
        {tab === 'home' && <>
          <section className="welcome">
            <div><p className="eyebrow">TU ESPACIO PERSONAL</p><h1>¡Hola! 👋</h1>
              <p className="muted">Aquí tienes el resumen de tu organización.</p></div>
            <div className="date-chip"><span>{today.toLocaleDateString('es-ES',{weekday:'short'}).toUpperCase()}</span><b>{today.getDate()}</b></div>
          </section>
          <section className="stats">
            <div className="stat-card"><span className="stat-icon blue"><ListTodo size={18}/></span><b>{pending.length}</b><small>Pendientes</small></div>
            <div className="stat-card"><span className="stat-icon green"><CheckCircle2 size={18}/></span><b>{completed.length}</b><small>Completadas</small></div>
            <div className="stat-card"><span className="stat-icon orange"><CalendarDays size={18}/></span><b>{events.filter(e=>e.date===iso(today)).length}</b><small>Para hoy</small></div>
          </section>
          <section className="section-heading"><div><h2>Próximas actividades</h2><p className="muted">Lo que viene a continuación</p></div><button className="text-btn" onClick={()=>setTab('tasks')}>Ver todas</button></section>
          <EventList events={upcoming} onToggle={toggleDone} onEdit={openEdit} onDelete={removeEvent} />
          <button className="primary wide" onClick={()=>openNew(iso(today))}><Plus size={19}/> Nueva actividad</button>
          <section className="tip-card"><div className="tip-icon"><Flag size={19}/></div><div><b>Un día bien organizado</b><p>Divide tus objetivos en pequeñas actividades y avanza paso a paso.</p></div></section>
        </>}

        {tab === 'calendar' && <>
          <section className="page-heading"><p className="eyebrow">PLANIFICACIÓN</p><h1>Calendario</h1><p className="muted">Consulta y organiza tus actividades.</p></section>
          <div className="calendar-card">
            <div className="calendar-head"><button className="icon-btn" onClick={()=>changeMonth(-1)}><ChevronLeft/></button><h2>{monthTitle}</h2><button className="icon-btn" onClick={()=>changeMonth(1)}><ChevronRight/></button></div>
            <div className="view-switch">{['month','week','day'].map(v=><button key={v} className={view===v?'active':''} onClick={()=>setView(v)}>{v==='month'?'Mes':v==='week'?'Semana':'Día'}</button>)}</div>
            {view === 'month' ? <div className="calendar-grid">
              {['L','M','X','J','V','S','D'].map(x=><span className="weekday" key={x}>{x}</span>)}
              {calendarDays.map((d,i)=>d ? <button key={d} className={`day-cell ${d===selectedDate?'selected':''} ${d===iso(today)?'today':''}`} onClick={()=>setSelectedDate(d)}><span>{Number(d.slice(-2))}</span>{events.some(e=>e.date===d&&!e.done)&&<i/>}</button> : <span key={`empty-${i}`}/>)}
            </div> : <div className="period-nav"><button className="icon-btn" onClick={()=>shiftDate(view==='week'?-7:-1)}><ChevronLeft/></button><b>{dateLabel(selectedDate)}</b><button className="icon-btn" onClick={()=>shiftDate(view==='week'?7:1)}><ChevronRight/></button></div>}
          </div>
          <div className="section-heading"><div><h2>{dateLabel(selectedDate)}</h2><p className="muted">{dayEvents.length} actividad(es) programada(s)</p></div><button className="round-add" onClick={()=>openNew()}><Plus/></button></div>
          <EventList events={dayEvents} onToggle={toggleDone} onEdit={openEdit} onDelete={removeEvent}/>
        </>}

        {tab === 'tasks' && <>
          <section className="page-heading"><p className="eyebrow">PRODUCTIVIDAD</p><h1>Mis tareas</h1><p className="muted">Todas tus actividades en un solo lugar.</p></section>
          <div className="search-box"><Search size={18}/><input placeholder="Buscar actividad..." value={query} onChange={e=>setQuery(e.target.value)}/></div>
          <div className="task-filters"><span>{pending.length} pendientes</span><span>{completed.length} completadas</span></div>
          <EventList events={sorted.filter(e=>`${e.title} ${e.category} ${e.notes}`.toLowerCase().includes(query.toLowerCase()))} onToggle={toggleDone} onEdit={openEdit} onDelete={removeEvent}/>
          <button className="primary wide" onClick={()=>openNew()}><Plus size={19}/> Añadir tarea</button>
        </>}

        {tab === 'notes' && <>
          <section className="page-heading"><p className="eyebrow">IDEAS Y APUNTES</p><h1>Notas</h1><p className="muted">Tus notas se guardan en este dispositivo.</p></section>
          <div className="notes-list">{events.filter(e=>e.notes).map(e=><button className="note-card" key={e.id} onClick={()=>openEdit(e)}><span className="note-icon"><StickyNote/></span><span><b>{e.title}</b><small>{e.notes}</small><em>{dateLabel(e.date,{day:'numeric',month:'short',year:'numeric'})}</em></span><Pencil size={16}/></button>)}</div>
          <button className="primary wide" onClick={()=>openNew()}><Plus size={19}/> Crear nota o actividad</button>
        </>}

        {tab === 'settings' && <>
          <section className="page-heading"><p className="eyebrow">PREFERENCIAS</p><h1>Ajustes</h1><p className="muted">Configuración de MyAgenda.</p></section>
          <div className="settings-card"><div className="settings-row"><span className="settings-icon"><Bell/></span><div><b>Notificaciones</b><small>Permitir avisos de actividades</small></div><button className="secondary small" onClick={async()=>{const p=await requestNotificationPermission();setNotice(p.display==='granted'?'Permiso concedido':'Permiso no concedido');setTimeout(()=>setNotice(''),2500)}}>Activar</button></div>
          <div className="settings-row"><span className="settings-icon"><CalendarDays/></span><div><b>Almacenamiento local</b><small>Los datos permanecen en este dispositivo.</small></div></div>
          <div className="settings-row"><span className="settings-icon"><Settings/></span><div><b>MyAgenda</b><small>Versión 1.0.0 · Aplicación personal</small></div></div></div>
          <p className="settings-foot">La sincronización en la nube y las cuentas de usuario podrán añadirse en una versión futura.</p>
        </>}
      </main>

      <nav className="bottom-nav">
        <NavItem active={tab==='home'} icon={<LayoutDashboard/>} label="Inicio" onClick={()=>setTab('home')}/>
        <NavItem active={tab==='calendar'} icon={<CalendarDays/>} label="Calendario" onClick={()=>setTab('calendar')}/>
        <NavItem active={tab==='tasks'} icon={<ListTodo/>} label="Tareas" onClick={()=>setTab('tasks')}/>
        <NavItem active={tab==='notes'} icon={<StickyNote/>} label="Notas" onClick={()=>setTab('notes')}/>
      </nav>

      {modal && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(false)}}><form className="event-modal" onSubmit={submit}>
        <div className="modal-head"><div><p className="eyebrow">{form.id?'MODIFICAR':'NUEVA' } ACTIVIDAD</p><h2>{form.id?'Editar actividad':'Crear actividad'}</h2></div><button type="button" className="icon-btn" onClick={()=>setModal(false)}><X/></button></div>
        <label>Título<input autoFocus required maxLength="80" placeholder="Ej. Estudiar inglés" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></label>
        <div className="form-two"><label>Fecha<input type="date" required value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></label><label>Hora<input type="time" required value={form.time} onChange={e=>setForm({...form,time:e.target.value})}/></label></div>
        <div className="form-two"><label>Categoría<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{['Personal','Trabajo','Estudios','Salud','Familia','Otros'].map(x=><option key={x}>{x}</option>)}</select></label><label>Prioridad<select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}>{['Baja','Normal','Alta'].map(x=><option key={x}>{x}</option>)}</select></label></div>
        <label>Notas (opcional)<textarea rows="3" placeholder="Añade detalles..." value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/></label>
        <label className="check-line"><input type="checkbox" checked={form.reminder} onChange={e=>setForm({...form,reminder:e.target.checked})}/> <Bell size={17}/> Recordarme a esta hora</label>
        <button className="primary wide" type="submit">Guardar actividad</button>
      </form></div>}
      {notice && <div className="toast">{notice}</div>}
    </div>
  );
}

function NavItem({active,icon,label,onClick}) {
  return <button className={`nav-item ${active?'active':''}`} onClick={onClick}>{icon}<span>{label}</span></button>;
}
function EventList({events,onToggle,onEdit,onDelete}) {
  if (!events.length) return <div className="empty-state"><div><CalendarDays size={25}/></div><b>No hay actividades</b><p>Añade una actividad para organizar tu tiempo.</p></div>;
  return <div className="event-list">{events.map(e=><article className={`event-card ${e.done?'is-done':''}`} key={e.id}>
    <button className="done-btn" aria-label="Cambiar estado" onClick={()=>onToggle(e)}>{e.done?<CheckCircle2/>:<Circle/>}</button>
    <button className="event-main" onClick={()=>onEdit(e)}><span className="event-title">{e.title}</span><span className="event-meta"><Clock3 size={13}/>{e.time} · {e.category} · {dateLabel(e.date,{day:'numeric',month:'short'})}</span>{e.notes&&<span className="event-notes">{e.notes}</span>}</button>
    <span className={`priority priority-${e.priority.toLowerCase()}`}>{e.priority}</span>
    <button className="delete-btn" aria-label="Eliminar actividad" onClick={()=>onDelete(e)}><Trash2 size={16}/></button>
  </article>)}</div>;
}
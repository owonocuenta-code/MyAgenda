# MyAgenda — React + Capacitor

Aplicación de agenda personal con calendario, tareas, notas, almacenamiento local y recordatorios Android.

## Requisitos
- Node.js LTS (recomendado 20 o 22)
- npm
- Android Studio estable
- Android SDK y JDK compatibles con la versión de Android Gradle Plugin que genere Capacitor

## 1. Instalar dependencias y ejecutar en el navegador
```bash
npm install
npm run dev
```
La vista web es útil para desarrollar. Los recordatorios nativos y el comportamiento Android deben probarse en un dispositivo o emulador.

## 2. Crear el proyecto Android
```bash
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
En Android Studio espera a que termine Gradle Sync. Selecciona un emulador o conecta un teléfono con depuración USB activada y pulsa Run.

Cada vez que modifiques React:
```bash
npm run build
npx cap sync android
```

## 3. Generar APK de depuración
Desde Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Normalmente se guarda en:
`android/app/build/outputs/apk/debug/app-debug.apk`

También puedes usar la terminal, desde la carpeta android:
```bash
./gradlew assembleDebug
```
En Windows:
```bat
gradlew.bat assembleDebug
```

## 4. Generar APK firmado (distribución)
En Android Studio:
1. **Build > Generate Signed Bundle / APK**.
2. Selecciona **APK**.
3. Crea un nuevo keystore (guárdalo en un lugar seguro).
4. Define y conserva las contraseñas y alias.
5. Selecciona **release** y termina el asistente.
6. El APK firmado aparecerá normalmente en `android/app/release/` o en la ruta indicada por Android Studio.

No compartas el keystore ni sus contraseñas. Conserva una copia segura: las actualizaciones futuras deben firmarse con la misma clave para actualizar la instalación existente.

Por terminal, si ya configuraste firma en Gradle:
```bash
./gradlew assembleRelease
```
No subas claves privadas al repositorio.

## 5. Permisos y notificaciones
El plugin `@capacitor/local-notifications` solicita el permiso de notificaciones en tiempo de ejecución. Android 13 o superior exige autorización para mostrar notificaciones. Android puede aplicar restricciones de batería y alarmas exactas; esta primera versión programa recordatorios locales estándar y no solicita permiso de alarmas exactas.

Revisa el `AndroidManifest.xml` generado por Capacitor y los permisos fusionados antes de publicar. No añadas permisos de cámara, ubicación o contactos si la app no los utiliza.

## 6. Datos y funcionamiento sin Internet
- Las actividades se guardan localmente mediante Capacitor Preferences en Android y `localStorage` en navegador.
- No se requiere cuenta ni servidor para las funciones actuales.
- Preferences es almacenamiento local ligero, no una base de datos relacional. Si crece el volumen de datos, migraremos a SQLite.
- La arquitectura separa almacenamiento (`src/storage.js`) y notificaciones (`src/notifications.js`) para facilitar esa ampliación.
- La fuente DM Sans se carga desde Google Fonts si hay Internet; sin conexión se utiliza una fuente del sistema. Para un funcionamiento visual completamente independiente se puede empaquetar una fuente local.

## 7. Pruebas recomendadas en Android
1. Instala `app-debug.apk`.
2. Activa notificaciones cuando Android lo solicite.
3. Crea una actividad futura con recordatorio.
4. Cierra la aplicación y comprueba que llega el aviso a la hora programada.
5. Reinicia el teléfono y verifica el comportamiento de recordatorios en el dispositivo.
6. Crea, edita, completa y elimina actividades.
7. Activa modo avión y verifica calendario, tareas y notas.
8. Desinstalar la app elimina los datos locales asociados; exportación y copia de seguridad no están implementadas todavía.

## Limitaciones de esta primera versión
- No hay sincronización entre teléfonos ni backend conectado.
- No hay inicio de sesión ni exportación/importación.
- Los recordatorios requieren permisos del sistema y pueden verse afectados por políticas de batería del fabricante.
- La compilación y la prueba física deben realizarse en un equipo con Android Studio/SDK y un dispositivo Android.

## Arquitectura futura
La capa de almacenamiento puede sustituirse por SQLite y añadirse un repositorio API para sincronizar con un backend. Mantén las pantallas desacopladas de la implementación concreta del almacenamiento.
